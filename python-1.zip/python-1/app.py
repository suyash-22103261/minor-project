from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector
from flask_bcrypt import Bcrypt
from datetime import datetime, timedelta
import pyotp
import io
import qrcode

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Make sure to use a secure key
bcrypt = Bcrypt(app)
# Dictionary to track failed login attempts
failed_attempts = {}

# Database connection function
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='suyash',
        database='flask_auth'
    )

@app.route('/')
def home():
    return render_template('index.html')

# Signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        db = get_db_connection()
        cursor = db.cursor()
        try:
            
            cursor.execute('INSERT INTO users (username, password) VALUES (%s, %s)', (username, hashed_password,))
            db.commit()

            flash('Account created successfully. Please log in.', 'success')
            return redirect(url_for('home'))
        except mysql.connector.Error as err:
            flash('Username already exists. Please choose another one.', 'error')
        finally:
            cursor.close()
            db.close()

    return render_template('signup.html')


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Check if the user is currently locked out
        if username in failed_attempts:
            lockout_time = failed_attempts[username]['lockout_time']
            if failed_attempts[username]['attempts'] >= 3 and lockout_time:
                if datetime.now() < lockout_time:
                    remaining_time = (lockout_time - datetime.now()).seconds // 60
                    flash(f'Account locked. Try again in {remaining_time} minutes.', 'error')
                    return redirect(url_for('login'))

        # Connect to the database and fetch the user
        db = get_db_connection()
        cursor = db.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        cursor.close()
        db.close()

        if user and bcrypt.check_password_hash(user['password'], password):
            # Successful login
            failed_attempts.pop(username, None)
            session['user_id'] = user['id']
            flash('Logged in successfully.', 'success')
            return redirect(url_for('dashboard'))
        else:
            # Handle failed login
            if username in failed_attempts:
                failed_attempts[username]['attempts'] += 1
                if failed_attempts[username]['attempts'] >= 3:
                    failed_attempts[username]['lockout_time'] = datetime.now() + timedelta(minutes=15)
                    flash('Too many failed attempts. Your account is locked for 15 minutes.', 'error')
            else:
                # Initialize the failed attempts record for the user
                failed_attempts[username] = {'attempts': 1, 'lockout_time': None}

            flash('Invalid login credentials. Please try again.', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')


import base64
@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        username = request.form.get('username')
        
        if not username:
            flash('Username is required.', 'error')
            return render_template('forgot_password.html')

        # Store the username in the session for later use
        session['forgot_password_username'] = username

        db = get_db_connection()
        cursor = db.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()

        if user:
            if user['totp_secret']:
                # User has TOTP enabled, go to OTP verification
                return redirect(url_for('verify_otp'))
            else:
                # TOTP is not enabled, generate QR code and proceed to TOTP setup
                return redirect(url_for('generate_and_verify_qr_code'))
        else:
            flash('User not found.', 'error')
            session.pop('forgot_password_username', None)  # Clear the session if user not found

        cursor.close()
        db.close()

    return render_template('forgot_password.html')

@app.route('/generate-and-verify-qr-code', methods=['GET', 'POST'])
def generate_and_verify_qr_code():
    username = session.get('forgot_password_username')

    if not username:
        flash('No username found. Please request a password reset.', 'error')
        return redirect(url_for('forgot_password'))

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
    user = cursor.fetchone()

    if user:
        if request.method == 'GET':
            # Generate TOTP secret and QR code for new setup
            totp = pyotp.TOTP(pyotp.random_base32())
            totp_secret = totp.secret

            # Store the new TOTP secret in the database
            cursor.execute('UPDATE users SET totp_secret = %s WHERE id = %s', (totp_secret, user['id']))
            db.commit()

            # Generate the TOTP URI for the QR code
            totp_uri = totp.provisioning_uri(user['username'], issuer_name="FlaskAuthApp")
            qr = qrcode.make(totp_uri)
            img_io = io.BytesIO()
            qr.save(img_io, 'PNG')
            img_io.seek(0)

            # Convert the image to base64 for rendering in the template
            img_base64 = base64.b64encode(img_io.getvalue()).decode('utf-8')

            # Store the TOTP secret in the session
            session['totp_secret'] = totp_secret

            # Show QR code to the user
            return render_template('scan_qr.html', qr_code=img_base64)

        elif request.method == 'POST':
            # Handle OTP verification for the user
            otp = request.form.get('otp')

            if not otp:
                flash('OTP is required.', 'error')
                return render_template('scan_qr.html')

            # Verify the OTP based on the newly generated secret
            totp_secret = session.get('totp_secret')
            if not totp_secret:
                flash('No TOTP secret found. Please try again.', 'error')
                return redirect(url_for('forgot_password'))

            totp = pyotp.TOTP(totp_secret)
            if totp.verify(otp, valid_window=1):
                flash('TOTP setup complete. You can now reset your password.', 'success')
                session['reset_user_id'] = user['id']  # Store user ID for password reset
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid OTP. Please try again.', 'error')

    cursor.close()
    db.close()

    return render_template('scan_qr_and_verify.html')

@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    username = session.get('forgot_password_username')

    if not username:
        flash('No username found. Please request a password reset.', 'error')
        return redirect(url_for('forgot_password'))

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
    user = cursor.fetchone()
    cursor.close()
    db.close()

    if user:
        if request.method == 'POST':
            otp = request.form.get('otp')

            if not otp:
                flash('OTP is required.', 'error')
                return render_template('verify_only_otp.html')

            totp = pyotp.TOTP(user['totp_secret'])
            if totp.verify(otp, valid_window=1):
                flash('2FA verified. You can now reset your password.', 'success')
                session['reset_user_id'] = user['id']  # Store user ID for password reset
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid OTP. Please try again.', 'error')

        return render_template('verify_only_otp.html')

    else:
        flash('User not found.', 'error')
        session.pop('forgot_password_username', None)  # Clear session if user not found
        return redirect(url_for('forgot_password'))

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if 'reset_user_id' not in session:
        flash('Unauthorized access. Please request a password reset.', 'error')
        return redirect(url_for('forgot_password'))

    if request.method == 'POST':
        new_password = request.form['password']
        hashed_password = bcrypt.generate_password_hash(new_password).decode('utf-8')

        db = get_db_connection()
        cursor = db.cursor()
       
        # Update the user's password
        cursor.execute('UPDATE users SET password = %s WHERE id = %s', (hashed_password, session['reset_user_id']))
        db.commit()

        # Clear the session after successful password reset
        session.pop('reset_user_id', None)

        flash('Your password has been reset. Please log in with your new password.', 'success')
        return redirect(url_for('login'))

    return render_template('reset_password.html')


# Logout route
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Dashboard route (example protected route)
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('You must be logged in to view this page.', 'warning')
        return redirect(url_for('login'))
    return render_template('dashboard.html')

if __name__ == '__main__':
    app.run(debug=True)

